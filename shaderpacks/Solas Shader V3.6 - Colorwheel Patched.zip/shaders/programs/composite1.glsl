#define COMPOSITE_0

// Setings //
#include "/lib/common.glsl"

#if !defined OVERWORLD || (!defined VL && !defined LPV_FOG)
#undef HALF_RES_VOLUMETRICS
#endif

#if defined FSH || defined COMPOSITE_VL_COMPUTE

#ifdef COMPOSITE_VL_COMPUTE
// Half resolution volumetric light & LPV fog raymarch, run as a compute shader right before this pass
layout (local_size_x = 8, local_size_y = 8) in;
const vec2 workGroupsRender = vec2(0.5, 0.5);

vec2 texCoord;
#else
// VSH Data //
in vec2 texCoord;
#endif

// Uniforms //
uniform sampler2D colortex0;

#if defined VL || defined LPV_FOG || defined NETHER_SMOKE
uniform int frameCounter;
uniform int isEyeInWater;

#if defined VL && defined VC_SHADOWS
uniform int worldDay, worldTime;
#endif

uniform float shadowFade;
uniform float far, near;
uniform float viewWidth, viewHeight;
#ifdef DISTANT_HORIZONS
uniform float dhFarPlane, dhNearPlane;
#endif
uniform float frameTimeCounter;
uniform float timeAngle, timeBrightness;
uniform float wetness;
uniform float blindFactor, nightVision;
#if MC_VERSION >= 11900
uniform float darknessFactor;
#endif

#if MC_VERSION >= 12104
uniform float isPaleGarden;
#endif

uniform ivec2 eyeBrightnessSmooth;

uniform vec3 skyColor, cameraPosition;

#ifdef NETHER
uniform vec3 fogColor;
#endif

uniform sampler2D colortex1;
uniform sampler2D colortex3;

#ifdef LPV_FOG
uniform sampler3D floodfillSampler, floodfillSamplerCopy;
#endif

uniform sampler2D noisetex;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowtex0, shadowtex1;
uniform sampler2D depthtex0, depthtex1;

#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0, dhDepthTex1;

uniform mat4 dhProjectionInverse;
#endif

#ifdef VOXY
uniform sampler2D vxDepthTexOpaque, vxDepthTexTrans;

uniform mat4 vxProjInv;
#endif
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
#endif

#ifdef HALF_RES_VOLUMETRICS
#ifdef COMPOSITE_VL_COMPUTE
writeonly uniform image2D vl_img;
#else
uniform sampler2D vlSampler;
#endif
#endif

// Global Variables //
#if defined VL || defined LPV_FOG
#if defined OVERWORLD
const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
float fractTimeAngle = fract(timeAngle - 0.25);
float ang = (fractTimeAngle + (cos(fractTimeAngle * 3.14159265358979) * -0.5 + 0.5 - fractTimeAngle) / 3.0) * 6.28318530717959;
vec3 sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);
#elif defined END
const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
vec3 sunVec = normalize((gbufferModelView * vec4(1.0, sunRotationData * 2000.0, 1.0)).xyz);
#else
vec3 sunVec = vec3(0.0);
#endif

vec3 upVec = normalize(gbufferModelView[1].xyz);

float eBS = eyeBrightnessSmooth.y / 240.0;
float caveFactor = mix(clamp((cameraPosition.y - 56.0) / 16.0, float(sign(isEyeInWater)), 1.0), 1.0, sqrt(eBS));
float sunVisibility = clamp((dot( sunVec, upVec) + 0.15) * 3.0, 0.0, 1.0);
float moonVisibility = clamp((dot(-sunVec, upVec) + 0.15) * 3.0, 0.0, 1.0);
vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
#endif

// Includes //
#if defined VL || defined LPV_FOG || defined NETHER_SMOKE
#include "/lib/util/transformMacros.glsl"
#include "/lib/util/ToView.glsl"
#include "/lib/util/ToWorld.glsl"
#include "/lib/util/ToShadow.glsl"
#include "/lib/color/lightColor.glsl"
#include "/lib/atmosphere/spaceConversion.glsl"

#if defined VL && defined VC_SHADOWS
#include "/lib/lighting/cloudShadows.glsl"
#endif

#ifdef LPV_FOG
#include "/lib/lighting/lightning.glsl"
#include "/lib/vx/voxelization.glsl"
#endif

#include "/lib/atmosphere/volumetrics.glsl"
#endif

#ifdef COMPOSITE_VL_COMPUTE
// Main //
void main() {
	#ifdef HALF_RES_VOLUMETRICS
	ivec2 lowResPixel = ivec2(gl_GlobalInvocationID.xy);
	ivec2 srcPixel = lowResPixel * 2;
	if (any(greaterThanEqual(lowResPixel, imageSize(vl_img))) || any(greaterThanEqual(srcPixel, ivec2(viewWidth, viewHeight)))) return;

	//Each low resolution pixel traces the top-left full resolution pixel of its 2x2 block
	texCoord = (vec2(srcPixel) + 0.5) / vec2(viewWidth, viewHeight);

	float blueNoiseDither = texture2D(noisetex, (vec2(lowResPixel) + 0.5) / 512.0).b;
	#ifdef TAA
		  blueNoiseDither = fract(blueNoiseDither + 1.61803398875 * mod(float(frameCounter), 3600.0));
	#endif

	vec3 translucent = texelFetch(colortex1, srcPixel, 0).rgb;

	//computeVolumetricLight only adds light, so trace it on its own and add it back in the fragment pass
	vec3 volumetrics = vec3(0.0);
	computeVolumetricLight(volumetrics, translucent, blueNoiseDither);

	imageStore(vl_img, lowResPixel, vec4(volumetrics, 1.0));
	#endif
}
#else
#ifdef HALF_RES_VOLUMETRICS
float getVLUpsampleDepth(sampler2D depthtex, ivec2 pixel) {
	float z = texelFetch(depthtex, pixel, 0).r;
	vec4 v = gbufferProjectionInverse * vec4(0.0, 0.0, z * 2.0 - 1.0, 1.0);
	return -v.z / v.w;
}

//Depth-aware upsampling using both the translucent (depthtex0) and opaque (depthtex1) depths, since the
//raymarch stops at the opaque surface and is tinted behind translucents
vec3 upsampleVolumetrics() {
	ivec2 pixel = ivec2(gl_FragCoord.xy);
	ivec2 base = pixel >> 1;
	ivec2 odd = pixel & 1;
	ivec2 lowResMax = textureSize(vlSampler, 0) - 1;
	ivec2 fullResMax = ivec2(viewWidth, viewHeight) - 1;

	float depth0 = getVLUpsampleDepth(depthtex0, pixel);
	float depth1 = getVLUpsampleDepth(depthtex1, pixel);

	vec3 volumetrics = vec3(0.0);
	float totalWeight = 0.0;
	vec3 closestVolumetrics = vec3(0.0);
	float closestDifference = 1e30;

	for (int i = 0; i <= odd.x; i++) {
		for (int j = 0; j <= odd.y; j++) {
			ivec2 lowResPixel = min(base + ivec2(i, j), lowResMax);
			ivec2 srcPixel = min(lowResPixel * 2, fullResMax);
			vec3 sampleVolumetrics = texelFetch(vlSampler, lowResPixel, 0).rgb;

			float difference = abs(getVLUpsampleDepth(depthtex0, srcPixel) - depth0) / max(depth0, 0.001)
			                 + abs(getVLUpsampleDepth(depthtex1, srcPixel) - depth1) / max(depth1, 0.001);
			float weight = 1.0 / (0.001 + difference);

			volumetrics += sampleVolumetrics * weight;
			totalWeight += weight;

			if (difference < closestDifference) {
				closestDifference = difference;
				closestVolumetrics = sampleVolumetrics;
			}
		}
	}

	//If no sample is at a similar depth, take the closest one rather than blending across the edge
	return closestDifference < 0.1 ? volumetrics / totalWeight : closestVolumetrics;
}
#endif

// Main //
void main() {
	vec3 color = texture2D(colortex0, texCoord).rgb;

	#if defined VL || defined LPV_FOG || defined NETHER_SMOKE
	#ifdef HALF_RES_VOLUMETRICS
	//Traced at half resolution by composite1_a.csh. computeVolumetricLight() also scales the scene color it
	//accumulates onto by its visibility factor (darkness, blindness), so apply that here to match
	float z0 = texture2D(depthtex0, texCoord).r;
	float totalVisibility = float(z0 > 0.56) * float(isEyeInWater != 2) * (1.0 - blindFactor);
	#if MC_VERSION >= 11900
	totalVisibility *= 1.0 - darknessFactor;
	#endif
	if (totalVisibility > 0.0) color *= totalVisibility;

	color += upsampleVolumetrics();
	#else
	vec3 volumetrics = vec3(0.0);

	float blueNoiseDither = texture2D(noisetex, gl_FragCoord.xy / 512.0).b;
	#ifdef TAA
		  blueNoiseDither = fract(blueNoiseDither + 1.61803398875 * mod(float(frameCounter), 3600.0));
	#endif

	vec3 translucent = texture2D(colortex1, texCoord).rgb;

	computeVolumetricLight(color, translucent, blueNoiseDither);
	#endif
	#endif

	/* DRAWBUFFERS:0 */
	gl_FragData[0].rgb = color;
}
#endif

#endif

//**//**//**//**//**//**//**//**//**//**//**//**//**//**//

#ifdef VSH

// VSH Data //
out vec2 texCoord;

// Main //
void main() {
	texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

	gl_Position = ftransform();
}

#endif
