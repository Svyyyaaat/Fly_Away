#version 430 compatibility

#define OVERWORLD
#define COMPOSITE_VL_COMPUTE

#include "/programs/composite1.glsl"
