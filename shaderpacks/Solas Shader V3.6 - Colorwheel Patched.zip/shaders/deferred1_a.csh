#version 430 compatibility

#define OVERWORLD
#define DEFERRED_CLOUDS_COMPUTE

#include "/programs/deferred1.glsl"
