//Based on BSL
vec3 computeScreenSpaceShadows(vec3 viewPos, vec3 lightVector, sampler2D depthtex, mat4 projection, mat4 projectionInverse,  float dither) {
	float shadow = 1.0;

	float traceZ = 0.0;
	float zDelta = 0.0;
	float thickness = 4.0;

	//Size of one pixel at this distance. Steps shorter than half of it stay within the starting pixel and only
	//re-read its own depth (which causes false self-shadowing on distant/LOD terrain), so they're skipped
	float halfPixelSize = -viewPos.z / (projection[1][1] * viewHeight);

	for (int i = 0; i < 16; i++) {
		float traceStep = exp2((i + dither) * 0.5 - 2.0);
		if (traceStep < halfPixelSize) {
			thickness += 0.5;
			continue;
		}
		vec3 tracePos = viewPos + lightVector * traceStep;

		vec4 pos = projection * vec4(tracePos, 1.0);
                pos = pos / pos.w * 0.5 + 0.5;

		if (pos.x < 0.0 || pos.x > 1.0 || pos.y < 0.0 || pos.y > 1.0) break;

		#ifdef VOXY
		traceZ = texture2D(depthtex0, pos.xy).r;
		zDelta = -tracePos.z - GetLinearDepth(traceZ, gbufferProjectionInverse);
		
		if (traceZ >= 1.0) {
		#endif
			traceZ = texture2D(depthtex, pos.xy).r;
			zDelta = -tracePos.z - GetLinearDepth(traceZ, projectionInverse);
		#ifdef VOXY
		}
		#endif

		shadow *= 1.0 - smoothstep(0.0, 0.5, zDelta) * smoothstep(thickness + 1.0, thickness, zDelta);
		thickness += 0.5;
	}

    #ifdef OVERWORLD
	vec3 shadowCol = ambientCol;
    #else
    vec3 shadowCol = endAmbientCol;
    #endif

	return mix(shadowCol, vec3(1.0), min(0.5 + shadow * 0.5, 1.0));
}