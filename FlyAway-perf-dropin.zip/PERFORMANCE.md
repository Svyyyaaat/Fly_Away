# Fly Away performance pass

This pass reduces CPU time on the client render thread, the client tick and the integrated server without
changing how the game looks or plays. It has three parts:

1. **`mods/flyaway_perf-0.1.0.jar`**: a new patch mod built from `perf-mod/`. It contains 63 mixins in 12 areas.
   Every patch can be switched off without rebuilding (see "Turning patches off" below).
2. **Config changes in `config/`**: only invisible ones. See `perf-mod/docs/configs.md`.
3. **One typo fix in the Solas shader**: in `shaders.properties`, `program.world0/deferred..enabled` became
   `deferred.enabled`. With the typo, turning SSAO off never removed the Overworld deferred pass.

Recommendations that would change visuals or gameplay, and the JVM/memory advice, are documented but **not
applied**. See "Things only you can do" below.

## Where the time went (your spark profile s4gidwMiAz, render thread, 92.6 s)

| Area | Render thread | What happens |
|---|---|---|
| `glBindFramebuffer` (Iris) | 8.4% self | Iris binds its FBO before every entity draw and rebinds the main target after it |
| Portal rendering (Immersive Portals) | 12.3% | The whole world is drawn again per portal, including the shadow pass |
| Portal occlusion query (sync GPU readback) | 1.3% here, **15.2%** in your 2026-10-03 profile | The CPU waits for the GPU to finish the frame |
| Entities / Epic Fight | 10.7% / 5.4% | Mostly per-mesh GL driver work |
| Xaero world map + minimap | ~5.5% | Map writing, texture upload, minimap FBO |
| Client tick | 15.8% | VSS LOD requests (hash collisions), radar curios lookups, animateTick biome lookups, ... |
| Iris custom uniforms | 1.8% | Every shader-pack uniform is re-uploaded on every draw |
| Aether cape check | ~1% | `parallel()` streams on the render thread on every skin lookup |

## Patches (details, profile numbers and risks are in `perf-mod/docs/*.md`)

| Area | Patch | Gain (render thread unless noted) |
|---|---|---|
| Iris | Custom-uniform upload dedup | ~1.2-1.5% |
| Iris | Lazy main-FBO rebind + `glUseProgram` dedup inside Iris entity batches | ~1-2% |
| Portals | Skip IP's synchronous same-frame occlusion read when last frame's "hidden" is fresh | 1.3% (up to ~15%) |
| Portals | `ImmPtlClientChunkMap.getChunk` fast path | ~1.5% |
| Portals | Per-frame cache of micimmptl's Sable straddle portal scans | ~0.6% |
| VSS | Fix colliding `Long` keys (tree bins) in `LodRequestManager` | ~0.6% |
| Xaero | VRAM query throttle, versioned region-highlight hash memo | ~0.5% |
| Client tick | `animateTick` biome lookups through a chunk memo | ~0.7% |
| Curios / Iron's | Memoised Curios item key; per-tick "ring equipped" memo (radar + name tags) | ~0.9% |
| Gliders | Glider-in-curios lookup cache | ~0.3% |
| Epic Fight | VAO attribute re-setup skip, hidden-flag SSBO upload dedup, class lookup cache | ~0.3% |
| aaa_particles | Skip Effekseer draws when nothing is playing; advance effects once per frame, not once per portal pass | up to ~1.1% |
| Colorwheel | Skip empty translucent Flywheel passes | ~0.6% |
| Create/Ponder | Placement-helper item match cache | ~0.2% |
| Aether | Sequential instead of parallel streams in `isCapeVisible` | ~1% |
| Architectury | Cache event-dispatch MethodHandles (was `unreflect` per listener per call) | ~0.1% client, ~2% server tick |
| Server | Spawner biome lookups without per-attempt chunk resolution; `mobsAt` built once | ~1% of server thread |
| Server | Chunk Activity Tracker saves moved off the server thread (autosave/ESC spike source) | spikes |
| Server / Sable | Skip the native Rapier physics step for dimensions without any ship/contraption/box | **~20% of the server thread** in a world without ships (every loaded dimension paid it) |
| Server (round 2) | Accessories idle-tick shortcut for mobs wearing nothing; Curios empty-modifier copy skip; EF Progressive Difficulty far-mob player scan skip; Simply Swords Hivemind bee check without a full entity scan | ~3.5-4% of the server thread |
| Iris (round 2) | Vanilla `iris_*` uniform upload dedup in ExtendedShader, constant sampler names, empty batch builder fast path | ~0.6-0.9% |
| Round-2 sweep | IP GC-bean list cache, IP collision box skip without global portals, Relics curio memo, Veil uniform hash map | ~0.6% (Oct 11) / ~1.1% (Oct 3) |

The estimates add up to roughly **10-15% of render-thread time** on your Oct 11 profile, plus up to another ~14%
in portal-heavy scenes like your Oct 3 profile (the occlusion stall). The test machine has no GPU, so these were not
measured on your hardware. Please profile again with spark (`/sparkc profiler start --thread *`, then
`/sparkc profiler stop`) and compare.

Intentional visible changes (each can be switched off):
- **Portals:** a portal emerging from behind a wall can appear one frame later
  (`imm_ptl.occlusion.noSyncWhenHidden=false` restores stock behaviour).
- **Effekseer effects** (aaa_particles) no longer play N times too fast while a portal is on screen. That was a bug
  (`mixin.compat.EffectDefinitionPortalDeltaMixin=false` restores it).

## Turning patches off

`config/flyaway_perf.properties` is created on first launch.
- Turn off a whole group with `area.<area>=false`. The areas are `vanilla`, `iris`, `imm_ptl`, `epicfight`,
  `xaero`, `sodium`, `flywheel`, `voxy`, `sable`, `vss` and `compat`.
- Turn off one patch with `mixin.<area>.<MixinClassName>=false`.
- If something looks wrong, bisect by area first.


## Gameplay fixes and features (round 4)

| What | Details | Off switch |
|---|---|---|
| Portal postcards | With shaders, a portal seen through another portal used to show nothing. It now shows an animated, pixelated paint swirl in the style of Balatro's background, in the destination dimension's colours: sky/grass for the Overworld, lava/crimson for the Nether, chorus/end stone for the End, sky/gold for the Aether, and colours derived from the fog for other dimensions. It has parallax, so the portal looks deep. The old snapshot mode is still available with `imm_ptl.postcards.style=snapshot`. Costs ~0 CPU. Details: `perf-mod/docs/portal_postcards.md` | `imm_ptl.postcards=false` |
| Camera vs portals | F5, Shoulder Surfing and Epic Fight's camera stop at portals like at a wall, so the camera can't slip behind a portal and render the wrong side. Just after you walk through, the camera hugs your head until you are ~4 blocks from the return portal, as it would against a wall. | `camera.portalsAreWalls=false` |
| TACZ recoil in Shoulder Surfing | The gun kick now moves the Shoulder Surfing camera like in vanilla F5. | `camera.taczRecoilInShoulderSurfing=false` |
| Hotbar slot jumping on portal entry | Root cause: Carry On re-sends a stale saved slot whenever you enter a level, and Immersive Portals' teleport never corrects it. Carry On's saved slot is now updated before it is sent. | `fix.keepHotbarSlotOnPortal=false` |
| Frozen particles in portal views | Particles from a dimension you're not in never move (IP only ticks the current dimension), so portal views now skip them. | `imm_ptl.hideFrozenPortalParticles=false` |
| Epic Fight fracture blocks | Each fracture block re-ran full smooth lighting for its whole model every frame (7% of your frame). Lighting lookups are now shared within a render pass, an identical image for about 4 of those 7%. NightFall trail slams also skip an unused entity scan per shockwave ray. | `mixin.epicfight.FractureBlockRendererLightMemoMixin=false` |
| Stutter catcher | Any frame over 150 ms writes what the game was doing to `logs/flyaway-hitches.log`. Send that file after a freeze. | `debug.hitchLogger=false`, threshold `debug.hitchMs` |

## Suggested fix for your own mod (not patched from here)

micimmptl `SubLevelGhostCollision.augmentIntersecting` costs about 0.7% of the server thread. On every collision of
every non-player entity, it builds a list of all levels and walks their usually empty sub-level containers. A mixin
from this pack would break the next time you rebuild micimmptl, so the fix is written up in
`perf-mod/docs/server.md` (Round 2) for you to apply in its source.

## Things only you can do (biggest remaining wins)

1. **Your PC is paging.** Spark showed 28.8 of 32 GB RAM in use and 41.9 of 42.5 GB of the page file used.
   - Every GC and every texture upload can stall on disk while this is happening. That alone can explain stutter
     and the 611 ms server spikes.
   - Close whatever is holding the memory (Task Manager > Details > Commit size column).
   - Then use the JVM arguments in `perf-mod/docs/configs.md` §6:
     - `-Xmx10G`;
     - G1 with `MaxGCPauseMillis=30` and 16M regions;
     - remove the useless Graal flags `-XX:+EagerJVMCI -Dgraal.TuneInlinerExploration=3`.
2. **Optional visual trade-offs**, with measured shares of your profile (`perf-mod/docs/configs.md` §3):

   | Option | Gain | Cost |
   |---|---|---|
   | Solas `shadowPlayer=false` | ~2.7% | You lose your own shadow |
   | Solas `shadowDistance` 192 -> 128 | ~2% | Shorter shadows |
   | Immersive Portals `maxPortalLayer` | less portal recursion | Fewer nested portal views |
   | Xaero `biome_blending` off | ~0.6-1% | Blockier biome borders on the map |

## Building and testing

- **Build:** `cd perf-mod && ./gradlew installToPack`. It builds against the exact jars in `mods/` and copies the
  jar there.
- **Test tools** (in `perf-mod/tools/`):
  - `launch.py`: a headless NeoForge launcher.
  - `bench.sh` / `abrun.sh`: run the whole pack under Xvfb and Mesa llvmpipe with a scripted benchmark world.
    `-Dflyaway.harness=bench` drives it: fixed seed, NoAI mobs, a nether portal, screenshots, spark on all threads,
    then exit.
  - `spark/`: Java tools that read `.sparkprofile` files (`Tree`, `Callers`, `Spark`).
- **Mixin check:** `-Dflyaway.logMixins=true` logs every applied mixin. In the final test run, 49 of 51 applied with the full pack. The other 2 target
  classes that only load when a Sable box body exists or a Sable vehicle crosses a portal.
